package com.example.demo;

import java.util.List;

public class LeituraRetornoBradesco implements LeituraRetorno {

    @Override
    public List<Boleto> lerArquivo(String nomeArquivo) {
        return null;
    }

}